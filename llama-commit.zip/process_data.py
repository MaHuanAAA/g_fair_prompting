import json
path = './glue/WNLI/dev'
file2 = open('{}.txt'.format(path),'w+', encoding='utf-8')

with open('{}.tsv'.format(path), 'r', encoding='utf-8') as f:
    next(f)  # 跳过第一行即可
    for idx, line in enumerate(f):
        line = line.strip().split('\t')
        print(line)
        if idx == 200:
            break
        file2.writelines('sentence1: '+line[1]+' sentence2: '+line[2]+'\t'+line[3]+'\n')
file2.close()
# file2 = open('{}.txt'.format(path),'r')
# for line in file2.readlines():
#     line = line.strip('\n').split('\t')
#     print(line)